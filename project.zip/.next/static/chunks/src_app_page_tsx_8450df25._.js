(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_8db48e5a._.js",
  "static/chunks/node_modules_chart_js_dist_fe1f3c5e._.js",
  "static/chunks/node_modules_xlsx_xlsx_mjs_ad755052._.js",
  "static/chunks/node_modules_8d91f160._.js"
],
    source: "dynamic"
});
