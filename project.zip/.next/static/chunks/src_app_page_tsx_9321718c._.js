(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0519a581._.js",
  "static/chunks/node_modules_next_91dc86d0._.js",
  "static/chunks/node_modules_chart_js_dist_fe1f3c5e._.js",
  "static/chunks/node_modules_xlsx_xlsx_mjs_ad755052._.js",
  "static/chunks/node_modules_6fccfccb._.js"
],
    source: "dynamic"
});
