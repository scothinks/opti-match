const CHUNK_PUBLIC_PATH = "server/app/api/validate/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_next_8d8b2afd._.js");
runtime.loadChunk("server/chunks/node_modules_xlsx_xlsx_mjs_2a6cf520._.js");
runtime.loadChunk("server/chunks/node_modules_fuzzball_dist_esm_fuzzball_esm_min_d7bd297b.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__6f745a6f._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/validate/route/actions.js [app-rsc] (server actions loader, ecmascript)", CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/validate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/validate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
